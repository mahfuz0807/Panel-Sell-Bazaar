# Panel Sell Bazaar — Full Starter

A Node.js/Express + SQLite digital-store starter with buyer login, packages, balance, orders, admin panel, and manual bKash/Nagad/Rocket fund requests.

## Manual payment flow
1. Admin opens `/admin.html` and sets the store payment numbers.
2. Buyer logs in, opens Add Fund, chooses bKash/Nagad/Rocket, enters amount, sender number and transaction ID.
3. Request appears in Admin Panel.
4. Admin checks the payment in the relevant provider app/account and clicks Approve or Reject.
5. Approve credits the buyer's website balance. The buyer can then place an order.

This is manual verification; it does not call the bKash/Nagad/Rocket APIs.

## Run locally
Install Node.js, then:

```bash
npm install
npm start
```
Open `http://localhost:3000`.

Default admin (change before real use):
- email: `admin@example.com`
- password: `ChangeThisPassword`

Set `ADMIN_EMAIL`, `ADMIN_PASSWORD`, and `SESSION_SECRET` as environment variables for a real deployment.

## Hosting note
The current version uses SQLite. Many free cloud web services use an ephemeral filesystem, so SQLite data can be lost after restarts/redeploys. For a real public store, migrate the database to hosted PostgreSQL (or use a paid persistent disk) before treating it as production data.

Never put payment PINs, OTPs, passwords, or API secrets in the browser code.
